SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

CREATE DATABASE `enterhos_medical` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `enterhos_medical`;

CREATE TABLE IF NOT EXISTS `allergy` (
  `idAllergy` int(11) NOT NULL auto_increment,
  `idPatient` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`idAllergy`),
  KEY `idPatient` (`idPatient`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

INSERT INTO `allergy` (`idAllergy`, `idPatient`, `name`) VALUES
(3, 1, 'sss'),
(9, 1, 'eee'),
(13, 1, '');

CREATE TABLE IF NOT EXISTS `case` (
  `idCase` int(11) NOT NULL auto_increment,
  `bedNo` varchar(45) default NULL,
  `addmitionDate` varchar(20) default NULL,
  `chiefComplain` text,
  `duration` varchar(45) default NULL,
  `onset` text,
  `site` varchar(45) default NULL,
  `severity` varchar(45) default NULL,
  `nature` varchar(45) default NULL,
  `radiation` varchar(45) default NULL,
  `aggravatingFactor` varchar(45) default NULL,
  `relievingFactor` varchar(45) default NULL,
  `associatedSymptom` text,
  `idPatient` int(11) default NULL,
  `idDoctor` int(11) default NULL,
  `status` varchar(1) NOT NULL default '1',
  PRIMARY KEY  (`idCase`),
  KEY `fk_Case_Patient` (`idPatient`),
  KEY `fk_Case_Doctor` (`idDoctor`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

INSERT INTO `case` (`idCase`, `bedNo`, `addmitionDate`, `chiefComplain`, `duration`, `onset`, `site`, `severity`, `nature`, `radiation`, `aggravatingFactor`, `relievingFactor`, `associatedSymptom`, `idPatient`, `idDoctor`, `status`) VALUES
(1, '1', '2009-12-16', '12', 'we', 'right', 'w', 'hard', '', '4', '4', '4', '4', 1, 1, '0'),
(2, '1', '0001-01-01', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, 1, '0'),
(3, '1', '0001-01-01', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, 1, '1'),
(4, '1', '0001-01-01', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, 1, '1'),
(5, '1', '0001-01-01', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 1, 1, '0'),
(6, '90', '90', '90', '90', '90', '90', '90', '90', '90', '90', '90', '90', 1, 1, '0'),
(7, '9', '9', '9', '9', '9', '9', '9', '9', '9', '9', '9', '9', 1, 1, '1');

CREATE TABLE IF NOT EXISTS `case_complain` (
  `idCase` int(11) NOT NULL,
  `idComplain` int(11) NOT NULL,
  `idSystem` int(11) NOT NULL,
  `notes` text,
  PRIMARY KEY  (`idCase`,`idComplain`,`idSystem`),
  KEY `fk_Case_has_Complain_Case` (`idCase`),
  KEY `fk_Case_has_Complain_Complain` (`idComplain`,`idSystem`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `case_complain` (`idCase`, `idComplain`, `idSystem`, `notes`) VALUES
(1, 4, 1, 'ghjkl;lkjhgfdfgh'),
(3, 3, 1, 'Hard'),
(3, 9, 1, ''),
(4, 3, 1, 'Hard'),
(4, 42, 4, ''),
(4, 65, 7, ''),
(4, 66, 7, '');

CREATE TABLE IF NOT EXISTS `complain` (
  `idComplain` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `idSystem` int(11) NOT NULL,
  PRIMARY KEY  (`idComplain`,`idSystem`),
  KEY `fk_Complain_System` (`idSystem`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

INSERT INTO `complain` (`idComplain`, `name`, `idSystem`) VALUES
(1, 'Dyspnea', 1),
(2, 'Palpitation', 1),
(3, 'Chest pain', 1),
(4, 'Gyanosis', 1),
(5, 'Peripheral edema', 1),
(6, 'Syncope', 1),
(7, 'Leg swelling', 1),
(8, 'Cramp like', 1),
(9, 'Fatigue', 1),
(10, 'Cough', 2),
(11, 'Sputum', 2),
(12, 'Haemoptysis', 2),
(13, 'Shortness of breath', 2),
(14, 'Chest pain', 2),
(15, 'Wheezing', 2),
(16, 'Stridor', 2),
(17, 'Xerostomia', 3),
(18, 'Wather brash', 3),
(19, 'Dysgeusia', 3),
(20, 'Heart Burn', 3),
(21, 'Cacageusia', 3),
(22, 'Halitosis', 3),
(23, 'Dysphagia', 3),
(24, 'Odenophagia', 3),
(25, 'Aphagia', 3),
(26, 'Regurgitation', 3),
(27, 'Nausea', 3),
(28, 'Haematamesis', 3),
(29, 'Melaena', 3),
(30, 'Abdominal', 3),
(31, 'Constiption', 3),
(32, 'Diarrhea', 3),
(33, 'Flatulence', 3),
(34, 'Jaudice', 3),
(35, 'Anorexia', 3),
(36, 'Weight Loss', 3),
(37, 'Hematochzia', 3),
(38, 'Dysuria', 4),
(39, 'Urgency', 4),
(40, 'Heamaturia', 4),
(41, 'Polyuria', 4),
(42, 'Oliguria', 4),
(43, 'Nocturia', 4),
(44, 'Incontinence', 4),
(45, 'Facial Puffiness', 4),
(46, 'Loin Pain', 4),
(47, 'Suprapubic Pain', 4),
(48, 'Hesitancy', 4),
(49, 'Headache', 5),
(50, 'Dizziness', 5),
(51, 'Syncope', 5),
(52, 'Epilepsy', 5),
(53, 'Numbness', 5),
(54, 'Hearing', 5),
(55, 'Vision', 5),
(56, 'Memory', 5),
(57, 'Speech', 5),
(58, 'Sleep Pattern', 5),
(59, 'Smel', 5),
(60, 'Joint Pain', 6),
(61, 'Joint Swelling', 6),
(62, 'Muscle Pain', 6),
(63, 'Pain on Movement', 6),
(64, 'Back Pain', 6),
(65, 'Polydepsia', 7),
(66, 'Polyuria', 7),
(67, 'Heat Intolerance', 7),
(68, 'Cold Intolerance', 7),
(69, 'Thirst', 7);

CREATE TABLE IF NOT EXISTS `doctor` (
  `idDoctor` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `spetiality` varchar(255) default NULL,
  `degree` varchar(45) default NULL,
  `currentKey` int(40) NOT NULL default '0',
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY  (`idDoctor`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

INSERT INTO `doctor` (`idDoctor`, `name`, `spetiality`, `degree`, `currentKey`, `username`, `password`) VALUES
(1, 'Aza A. Fattah', 'Bone', 'PhD', 236, 'aza', '123456');

CREATE TABLE IF NOT EXISTS `drughistory` (
  `idDrugHistory` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `dose` varchar(45) default NULL,
  `timePerDay` int(11) default NULL,
  `duration` varchar(45) default NULL,
  `idPatient` int(11) default NULL,
  PRIMARY KEY  (`idDrugHistory`),
  KEY `fk_DrugHistory_Patient` (`idPatient`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `familyhistory` (
  `idFamilyHistory` int(11) NOT NULL auto_increment,
  `type` varchar(45) default NULL,
  `description` text,
  `idPatient` int(11) default NULL,
  PRIMARY KEY  (`idFamilyHistory`),
  KEY `fk_FamilyHistory_Patient` (`idPatient`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

INSERT INTO `familyhistory` (`idFamilyHistory`, `type`, `description`, `idPatient`) VALUES
(1, 'Cancer ', '', 1);

CREATE TABLE IF NOT EXISTS `patient` (
  `idPatient` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `gender` varchar(15) default NULL,
  `religion` varchar(45) default NULL,
  `address` varchar(255) default NULL,
  `occupation` varchar(255) default NULL,
  `maritalStatus` varchar(50) default NULL,
  `education` varchar(50) default NULL,
  `houseStatus` varchar(50) default NULL,
  `diet` varchar(50) default NULL,
  `economicState` varchar(50) default NULL,
  `alchoholTaking` tinyint(1) default NULL,
  `smoking` tinyint(1) default NULL,
  `domesticAnimal` varchar(45) default NULL,
  `travelAbroad` varchar(255) default NULL,
  PRIMARY KEY  (`idPatient`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

INSERT INTO `patient` (`idPatient`, `name`, `gender`, `religion`, `address`, `occupation`, `maritalStatus`, `education`, `houseStatus`, `diet`, `economicState`, `alchoholTaking`, `smoking`, `domesticAnimal`, `travelAbroad`) VALUES
(1, '1', 'Male', '1', '1', '1', '1', 'polla', '12', '989', '898', 17, 56, '54', '1'),
(2, '2', '22', '2', '22', '2', '2', '2', '2', '2', '2', 2, 2, '2', '2'),
(3, '23', '23', '23', '2', '3', '23', '23', '2', '32', '32', 3, 23, '23', '22'),
(4, '3', '3', '3', '3', '3', '3', '3', '3', '3', '3', 3, 3, '3', '3'),
(5, '5', '5', '5', '5', '5', '1', '5', '5', '5', '5', 5, 5, '5', '3'),
(6, '3', '4', '4', '4', '54', '4', '4', '4', '4', '4', 4, 56, '4', '4'),
(7, '2', '2', '2', '2', '2', '2', '2', '2', '2', '2', 2, 2, '2', '2');

CREATE TABLE IF NOT EXISTS `surgicalhistory` (
  `idSurgicalHistory` int(11) NOT NULL auto_increment,
  `name` varchar(45) default NULL,
  `type` varchar(45) default NULL,
  `Patient_idPatient` int(11) default NULL,
  PRIMARY KEY  (`idSurgicalHistory`),
  KEY `fk_SurgicalHistory_Patient` (`Patient_idPatient`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

INSERT INTO `surgicalhistory` (`idSurgicalHistory`, `name`, `type`, `Patient_idPatient`) VALUES
(1, 'Test1', 'This is Test1', 1),
(2, 'Test2', 'This is Test2', 1);

CREATE TABLE IF NOT EXISTS `system` (
  `idSystem` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`idSystem`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

INSERT INTO `system` (`idSystem`, `name`) VALUES
(1, 'Cardiovascular System'),
(2, 'Respiratory System'),
(3, 'Gastrointestinal System (GIT)'),
(4, 'Genitourinary System'),
(5, 'Central Nervous System'),
(6, 'Locomotive System'),
(7, 'Endocrine System');


ALTER TABLE `allergy`
  ADD CONSTRAINT `allergy_ibfk_1` FOREIGN KEY (`idPatient`) REFERENCES `patient` (`idPatient`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `case`
  ADD CONSTRAINT `fk_Case_Doctor` FOREIGN KEY (`idDoctor`) REFERENCES `doctor` (`idDoctor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Case_Patient` FOREIGN KEY (`idPatient`) REFERENCES `patient` (`idPatient`) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE `case_complain`
  ADD CONSTRAINT `case_complain_ibfk_1` FOREIGN KEY (`idComplain`) REFERENCES `complain` (`idComplain`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Case_has_Complain_Case` FOREIGN KEY (`idCase`) REFERENCES `case` (`idCase`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Case_has_Complain_Complain` FOREIGN KEY (`idComplain`, `idSystem`) REFERENCES `complain` (`idComplain`, `idSystem`) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE `complain`
  ADD CONSTRAINT `fk_Complain_System` FOREIGN KEY (`idSystem`) REFERENCES `system` (`idSystem`) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE `drughistory`
  ADD CONSTRAINT `fk_DrugHistory_Patient` FOREIGN KEY (`idPatient`) REFERENCES `patient` (`idPatient`) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE `familyhistory`
  ADD CONSTRAINT `fk_FamilyHistory_Patient` FOREIGN KEY (`idPatient`) REFERENCES `patient` (`idPatient`) ON DELETE NO ACTION ON UPDATE NO ACTION;

ALTER TABLE `surgicalhistory`
  ADD CONSTRAINT `fk_SurgicalHistory_Patient` FOREIGN KEY (`Patient_idPatient`) REFERENCES `patient` (`idPatient`) ON DELETE NO ACTION ON UPDATE NO ACTION;
